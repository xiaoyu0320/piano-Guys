export default {
    avatar :'http://wallet.ascchain.com/uploads/20190802/0269e809cd266bf9ed338a4d3c27868b.png'
}