<template>
    <div class="empty">
      {{$t("message.Nodata")}}
    </div>
</template>
<script>
export default {
    
}
</script>
<style  scoped>
   .empty{
       font-size: 14px;
       color: #999;
       text-align: center;
      line-height: 60px
   }
</style>
